# Prime Unity Store

React + Vite starter project based on the supplied mobile store screenshots.

## Run in GitHub Codespaces

1. Upload this ZIP to a new GitHub repository and extract it, or upload the included files into your repository.
2. Open the repository in **Code → Codespaces → Create codespace**.
3. In the Codespaces terminal run:

```bash
npm install
npm run dev
```

4. Open the forwarded port **5173** when Codespaces shows the popup.

## Customize

- Product names, categories, prices and image links: `src/App.jsx`
- Colors, spacing, mobile/desktop layout: `src/style.css`
- Page title: `index.html`

This is a front-end demo. Login, real payment, order storage, and a live product database are not connected yet. Product photos load from Unsplash, so an internet connection is needed for those images.
