import React, { useMemo, useState } from 'react';

const products = [
  { id: 1, category: 'Khamiisyada', label: 'KHAMIISYADA', name: 'Khamiis Emirati Cad', price: 35, old: 45, rating: '4.9', reviews: 45, tag: 'Cusub', image: 'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=900&q=85' },
  { id: 2, category: 'Suits-ka', label: 'SUITS', name: 'Suit Blue Rasmi ah (3 Pcs)', price: 120, rating: '5.0', reviews: 12, image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=900&q=85' },
  { id: 3, category: 'Kabaha', label: 'KABAHA', name: 'Kabo Maqaar Italian ah', price: 55, rating: '4.8', reviews: 89, image: 'https://images.unsplash.com/photo-1614252369475-531e9e6e7cba?auto=format&fit=crop&w=900&q=85' },
  { id: 4, category: 'Jaakadaha', label: 'JAAKADAHA', name: 'Jaakad Maqaar Madow', price: 65, old: 80, rating: '4.7', reviews: 34, image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=900&q=85' },
  { id: 5, category: 'Shaadhadhka', label: 'SHAADHADHKA', name: 'Shaadh Cotton Rasmi ah', price: 25, rating: '4.6', reviews: 22, image: 'https://images.unsplash.com/photo-1603252109303-2751441dd157?auto=format&fit=crop&w=900&q=85' },
  { id: 6, category: 'Daryeel', label: 'HIDAHA & DHAQANKA', name: 'Garmaan / Shaal Qeexan', price: 40, rating: '4.9', reviews: 50, image: 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?auto=format&fit=crop&w=900&q=85' }
];

const categories = ['Dhammaan', 'Suits-ka', 'Khamiisyada', 'Kabaha', 'Jaakadaha', 'Shaadhadhka', 'Daryeel'];

function App() {
  const [category, setCategory] = useState('Dhammaan');
  const [search, setSearch] = useState('');
  const [cart, setCart] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const [tab, setTab] = useState('home');
  const [showCart, setShowCart] = useState(false);

  const visibleProducts = useMemo(() => products.filter(p =>
    (category === 'Dhammaan' || p.category === category) &&
    (p.name.toLowerCase().includes(search.toLowerCase()) || p.label.toLowerCase().includes(search.toLowerCase()))
  ), [category, search]);

  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  function addToCart(product) {
    setCart(current => {
      const found = current.find(item => item.id === product.id);
      return found ? current.map(item => item.id === product.id ? { ...item, qty: item.qty + 1 } : item) : [...current, { ...product, qty: 1 }];
    });
  }
  function toggleFavorite(id) {
    setFavorites(current => current.includes(id) ? current.filter(x => x !== id) : [...current, id]);
  }

  return (
    <div className="app-shell">
      <header className="top-header">
        <div className="brand-row">
          <div className="avatar">PU</div>
          <div className="welcome"><span>Kuso dhawoow,</span><strong>Ahmed Maxamed</strong></div>
          <div className="points"><span className="star">★</span><div><small>DHIBCAHAAGA</small><b>1,250 PTS</b></div></div>
        </div>
        <div className="search-wrap">
          <span className="search-icon">⌕</span>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Raadi dhar, khamiisyo, suits, kabo..." />
          <button className="filter-btn" aria-label="Filters">☷</button>
        </div>
      </header>

      <main>
        <section className="category-section">
          <div className="section-heading"><h2>Qaybaha Alaabta</h2><button onClick={() => setCategory('Dhammaan')}>Dhamaan Ku Eeg</button></div>
          <div className="category-list">
            {categories.map((c, i) => <button key={c} onClick={() => setCategory(c)} className={`category-chip ${category === c ? 'active' : ''}`}>
              <span>{['▦','♟','◆','◈','▰','▤','✦'][i]}</span>{c}
            </button>)}
          </div>
        </section>

        <section className="promo">
          <div className="promo-content">
            <span className="promo-tag">QIIMO DHIMIS EID</span>
            <h1>Hel Usbuucan 30% Off</h1>
            <p>Khamiisyada cusub iyo Suits-ka keenay.</p>
            <button onClick={() => { setCategory('Dhammaan'); window.scrollTo({ top: 700, behavior: 'smooth' }); }}>Isoobi Hada</button>
          </div>
          <div className="bag-watermark">♧</div>
        </section>

        <section className="products-section">
          <div className="section-heading product-heading"><h2>{tab === 'favorites' ? 'Alaabta Aad Jeceshahay' : 'Alaabta Loogu Jecelyahay'}</h2><span>{visibleProducts.length} Alaab oo Diyaar ah</span></div>
          {tab === 'favorites' ? (
            <div className="product-grid">
              {visibleProducts.filter(p => favorites.includes(p.id)).map(p => <ProductCard key={p.id} product={p} favorites={favorites} toggleFavorite={toggleFavorite} addToCart={addToCart} />)}
            </div>
          ) : (
            <div className="product-grid">
              {visibleProducts.map(p => <ProductCard key={p.id} product={p} favorites={favorites} toggleFavorite={toggleFavorite} addToCart={addToCart} />)}
            </div>
          )}
          {visibleProducts.length === 0 && <div className="empty">Wax alaab ah lama helin. Isku day eray kale.</div>}
        </section>
      </main>

      <div className="cart-bar">
        <div className="cart-total"><span className="cart-icon">🛍️<i>{cartCount}</i></span><div><small>Wadarta Qarashka:</small><strong>${total.toFixed(2)}</strong></div></div>
        <button onClick={() => setShowCart(true)}>Kala Bixi (Checkout)</button>
      </div>

      <button className="assistant-fab" aria-label="Assistant">✦</button>
      <nav className="bottom-nav">
        <button className={tab === 'home' ? 'selected' : ''} onClick={() => { setTab('home'); setCategory('Dhammaan'); }}><span>⌂</span>Home</button>
        <button onClick={() => setCategory('Dhammaan')}><span>▣</span>Store</button>
        <button className={tab === 'favorites' ? 'selected' : ''} onClick={() => setTab('favorites')}><span>♙</span>Favorites</button>
        <button onClick={() => setShowCart(true)}><span>♟</span>Profile</button>
      </nav>

      {showCart && <div className="modal-backdrop" onClick={() => setShowCart(false)}><div className="cart-modal" onClick={e => e.stopPropagation()}>
        <div className="modal-title"><h2>Shopping Cart</h2><button onClick={() => setShowCart(false)}>✕</button></div>
        {cart.length === 0 ? <p className="empty">Wali waxba kuma jiraan dambiishaada.</p> : cart.map(item => <div className="cart-line" key={item.id}><span>{item.name} × {item.qty}</span><b>${(item.price * item.qty).toFixed(2)}</b></div>)}
        <div className="modal-total"><span>Wadarta</span><strong>${total.toFixed(2)}</strong></div>
        <button className="checkout-btn" onClick={() => alert('Mahadsanid! Checkout-ka waxaa lagu xiri doonaa payment system-kaaga.')}>Sii wad Checkout</button>
      </div></div>}
    </div>
  );
}

function ProductCard({ product, favorites, toggleFavorite, addToCart }) {
  return <article className="product-card">
    <div className="image-wrap">
      <img src={product.image} alt={product.name} loading="lazy" />
      {product.tag && <span className="new-tag">{product.tag}</span>}
      <button className={`heart ${favorites.includes(product.id) ? 'liked' : ''}`} onClick={() => toggleFavorite(product.id)} aria-label="Favorite">{favorites.includes(product.id) ? '♥' : '♡'}</button>
    </div>
    <div className="product-info">
      <span className="product-label">{product.label}</span>
      <h3>{product.name}</h3>
      <div className="rating"><span>★</span><b>{product.rating}</b><small>({product.reviews})</small></div>
      <div className="price-row"><div><strong>${product.price.toFixed(2)}</strong>{product.old && <del>${product.old.toFixed(2)}</del>}</div><button className="add-btn" onClick={() => addToCart(product)}>+</button></div>
    </div>
  </article>;
}

export default App;
