# Prime Unity Store (Installable PWA)

## Run in GitHub Codespaces
```bash
npm install
npm run dev
```
Open forwarded port **5173**.

## Publish it online
Deploy this Vite project to a public HTTPS host such as Vercel or Netlify. The app must be served over HTTPS for installation and service workers.

## Install on Android
1. Open the public HTTPS website in Chrome.
2. Open Chrome's three-dot menu.
3. Tap **Install app** or **Add to Home screen**.
4. Confirm. The Prime Unity icon will appear on your phone.

## Files
- `src/App.jsx`: products, categories, cart and favorites.
- `src/style.css`: visual design and responsive layout.
- `public/manifest.webmanifest`: installable app information.
- `public/sw.js`: basic offline app-shell cache.
- `public/icons/`: app icons.

This is still a front-end demo. Login, online payments, order storage, and a live product database need to be connected separately.
