 "use client";

import { useMemo, useState } from "react";

const categories = [
  "All", "Phones & Electronics", "Women’s Fashion", "Men’s Fashion",
  "Kids & Baby", "Home & Furniture", "Beauty", "Cars",
  "Work Vehicles", "Construction Materials", "Construction Machinery",
  "Agriculture", "Electrical Equipment", "Water & Plumbing",
  "Bicycles & E-bikes", "Motorbikes", "Skateboards & Skates",
  "Sports & Outdoors", "Tools & Hardware", "Jewellery"
];

const products = [
  {id:1,name:"Modern smartphone",category:"Phones & Electronics",price:699,image:"https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=900"},
  {id:2,name:"Wireless headphones",category:"Phones & Electronics",price:89,image:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=900"},
  {id:3,name:"Elegant abaya",category:"Women’s Fashion",price:75,image:"https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=900"},
  {id:4,name:"Men’s casual outfit",category:"Men’s Fashion",price:95,image:"https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=900"},
  {id:5,name:"Modern living room chair",category:"Home & Furniture",price:240,image:"https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=900"},
  {id:6,name:"Beauty and skincare set",category:"Beauty",price:42,image:"https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?w=900"},
  {id:7,name:"Premium car",category:"Cars",price:28500,image:"https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=900"},
  {id:8,name:"Commercial delivery truck",category:"Work Vehicles",price:19500,image:"https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?w=900"},
  {id:9,name:"Construction materials",category:"Construction Materials",price:18,image:"https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=900"},
  {id:10,name:"Construction excavator",category:"Construction Machinery",price:42000,image:"https://images.unsplash.com/photo-1580901368919-7738efb0f87e?w=900"},
  {id:11,name:"Farm tractor",category:"Agriculture",price:18500,image:"https://images.unsplash.com/photo-1592982537447-6f2a6a0b4f7b?w=900"},
  {id:12,name:"Electrical equipment",category:"Electrical Equipment",price:130,image:"https://images.unsplash.com/photo-1621905251918-48416bd8575a?w=900"},
  {id:13,name:"Water pump and plumbing",category:"Water & Plumbing",price:165,image:"https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?w=900"},
  {id:14,name:"City bicycle",category:"Bicycles & E-bikes",price:320,image:"https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=900"},
  {id:15,name:"Motorbike",category:"Motorbikes",price:2100,image:"https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=900"},
  {id:16,name:"Skateboard",category:"Skateboards & Skates",price:65,image:"https://images.unsplash.com/photo-1520045892732-304bc3ac5d8e?w=900"},
  {id:17,name:"Professional tool set",category:"Tools & Hardware",price:155,image:"https://images.unsplash.com/photo-1581147036324-c1c89c2c8b5c?w=900"},
  {id:18,name:"Jewellery collection",category:"Jewellery",price:110,image:"https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=900"}
];

const copy = {
  English: {tag:"GLOBAL ONLINE MARKETPLACE",headline:"Everything you need.",sub:"Shop fashion, electronics, home essentials, construction supplies, farming equipment and more.",search:"Search products, tools, vehicles and brands…",shop:"Explore marketplace",categories:"Explore departments",popular:"Popular products",add:"Add to cart",cart:"Cart"},
  Somali: {tag:"SUUQA CAALAMIGA AH EE INTERNETKA",headline:"Wax kasta oo aad u baahan tahay.",sub:"Ka iibso dhar, telefoonno, alaabta guriga, qalabka dhismaha, beeraha iyo waxyaabo kale.",search:"Raadi alaab, qalab, gaadiid…",shop:"Eeg suuqa",categories:"Qaybaha suuqa",popular:"Alaabta caanka ah",add:"Ku dar gaariga",cart:"Gaariga"},
  Arabic: {tag:"السوق العالمي عبر الإنترنت",headline:"كل ما تحتاجه.",sub:"تسوق الأزياء والإلكترونيات والأثاث ومستلزمات البناء والزراعة والمزيد.",search:"ابحث عن المنتجات والأدوات والمركبات…",shop:"تسوق الآن",categories:"الأقسام",popular:"منتجات شائعة",add:"أضف إلى السلة",cart:"السلة"}
};

export default function Home() {
  const [lang,setLang] = useState("English");
  const [category,setCategory] = useState("All");
  const [query,setQuery] = useState("");
  const [cart,setCart] = useState([]);
  const t = copy[lang];
  const shown = useMemo(() => products.filter(p =>
    (category==="All" || p.category===category) &&
    (p.name+" "+p.category).toLowerCase().includes(query.toLowerCase())
  ),[category,query]);

  return <main>
    <header className="topbar">
      <a className="brand" href="#"><span className="brandMark">P</span><span>PRIME <b>UNITY</b><small>{t.tag}</small></span></a>
      <div className="search"><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={t.search}/><button onClick={()=>{}}>{lang==="Arabic"?"بحث":"Search"}</button></div>
      <select aria-label="Language" value={lang} onChange={e=>setLang(e.target.value)}><option>English</option><option>Somali</option><option>Arabic</option></select>
      <button className="cartButton" onClick={()=>alert(cart.length ? cart.map(x=>x.name).join("\\n") : "Your cart is empty")}>🛒 {t.cart} ({cart.length})</button>
    </header>

    <section className="hero">
      <div><span className="goldLabel">ONE WORLD. ONE MARKETPLACE.</span><h1>{t.headline}</h1><p>{t.sub}</p><a className="goldButton" href="#catalogue">{t.shop} →</a></div>
      <div className="heroPhoto"><img src="https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=1200" alt="Modern global city skyline"/></div>
    </section>

    <section className="section">
      <div className="sectionTitle"><div><h2>{t.categories}</h2><p>Browse real product categories</p></div></div>
      <div className="categoryGrid">{categories.map(c=><button key={c} onClick={()=>setCategory(c)} className={category===c?"category active":"category"}>{c}</button>)}</div>
    </section>

    <section className="rewards"><div><span className="goldLabel">PRIME REWARDS</span><h2>Shop more. Earn points. Unlock VIP gifts.</h2><p>Build your rewards balance with eligible purchases and progress through 100+ levels.</p></div><strong>LEVEL 1 → 100+ VIP</strong></section>

    <section className="section" id="catalogue">
      <div className="sectionTitle"><div><h2>{t.popular}</h2><p>{shown.length} products shown · Demo catalogue</p></div></div>
      <div className="productGrid">{shown.map(p=><article className="product" key={p.id}><div className="productImage"><img src={p.image} alt={p.name} loading="lazy" onError={e=>{e.currentTarget.src="https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?w=900"}}/></div><div className="productInfo"><span>{p.category}</span><h3>{p.name}</h3><b>${p.price.toLocaleString()}</b><button onClick={()=>setCart(old=>[...old,p])}>{t.add}</button></div></article>)}</div>
    </section>
    <footer><b>PRIME UNITY</b><span>One World. One Marketplace.</span><span>Prototype — connect verified sellers, payments and delivery before launch.</span></footer>
  </main>;
}