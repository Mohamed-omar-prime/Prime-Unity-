# PRIME UNITY — starter website

This is a learning prototype for the PRIME UNITY marketplace.

## Run it in GitHub Codespaces

1. Create a GitHub repository and upload these files.
2. Open the repository, choose **Code → Codespaces → Create codespace**.
3. In the terminal run:

```bash
npm install
npm run dev
```

4. Open the forwarded port 3000 preview.

## Important before real launch

This starter contains sample products, sample prices, a front-end cart and three example interface languages. It does NOT process real payments or orders and is not a production store.

Next build steps:
- Replace sample image links with product photos you own or have permission to use.
- Add Supabase database, authentication, image storage and Row Level Security.
- Add seller verification, stock, shipping, returns and customer support workflows.
- Integrate a payment provider that legally supports the countries you serve.
- Add professional translations and review Arabic right-to-left layout.
- Add server-side validation, access controls, audit logs and security testing.

Never put database service-role keys, payment secrets or AI API keys in browser code. Use server-side environment variables. Ask a trusted adult to help review account, payment and business setup requirements.
