import "./globals.css";
export const metadata = { title: "PRIME UNITY | Global Marketplace", description: "PRIME UNITY marketplace demo" };
export default function RootLayout({children}) { return <html lang="en"><body>{children}</body></html>; }
