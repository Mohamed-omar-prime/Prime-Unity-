# PRIME UNITY — Owner Edition

Clean Next.js + React starter project.

Includes a navy/gold responsive marketplace demo, departments, sample product photos, search, category filters, a demo cart, and footer ownership credit: **Founder & Owner — Mohamed-omar-prime**.

## Run in GitHub Codespaces
Open Terminal in the project root and run:

    npm install
    npm run dev

Then open port 3000 in the browser.

## Important
This is a front-end demo, not a live marketplace. It has no real database, accounts, seller tools, payments, shipping, or AI support. Sample product photos are placeholders; use photos you own or are licensed to use.

For real payments, business arrangements, and customer data, involve a trusted adult and follow local rules. Never put passwords or secret API keys in browser-side code.
